<?php
/* ============================ */
/*		Larshin Oleg 			*/
/*		SalesMan CRM 2018		*/
/* ============================ */


$apikey = "x5af26JFNRGJT1Hkh7NodsLhtnUDKP";
$user = "admin"; 


$crmurl = "http://test.sm-crm.ru/developer/v2/";

$clientbaseurl = $crmurl."client.php";//URL для создания клиента
$dealbaseurl = $crmurl."deal.php";//URL для создания сделки


?>